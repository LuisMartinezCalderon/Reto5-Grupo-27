
import java.sql.SQLException;

import controlador.ControladorRequerimientos;


public class Main {
    public static void main(String[] args) throws SQLException {
        ControladorRequerimientos  controlador =new ControladorRequerimientos();
  
    controlador.MostrarGraficaPripal();
 
        

    }
}
